﻿ /* write a method that takes an array of strings (i.e. string[] s)
 * , sort them alphabetically and return the resulting array  
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q3
{
    class Q3
    {
        // put your code here
    }
}