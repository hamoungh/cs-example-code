﻿/* define the classes and methods that are
 * neccessary to compile the tester4.cs code
 * */

namespace q4
{
    // put your classes here 
}