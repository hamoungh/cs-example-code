﻿/*
 / Write a function called 'GenerateRandomCoordinates'
 * To generate 50 random coordinates
 * in a two-dimensional coordinate system 
 * within The box (10,10) and (40,40) 
 * using a for loop. 
 * it should put this random points into
 * the given array of integers x,y which are passed 
 * as an argument 
 * (please look at the tester)
*/
using System;
namespace q2
{
    class Q2
    {
        // put your code here
    }
}