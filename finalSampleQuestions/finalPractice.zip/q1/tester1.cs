﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q1
{
    class tester1
    {
        static void Main(string[] args)
        {
            int i =
            new mathlib.Calculator().GetMax(5, 4);
            Console.WriteLine(i); 
        }
    }
}
