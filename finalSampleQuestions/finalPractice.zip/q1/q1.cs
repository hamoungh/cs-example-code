﻿/*
 *  define a namespace called mathlib, 
 *  Inside the namespace define a class called Calculator
 *  Define the method GetMax Inside the class 
 *  that takes two integers and returns the maximum.
 * Look at the tester.cs for a test case
*/


