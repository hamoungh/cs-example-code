﻿/* define the classes and methods that are
 * neccessary to compile the tester code.
 * you need to define a list inside Player class that stores
 * his pickUps */ 

namespace q5
{
    // put your classes here 
}
