﻿/*
 * write a function called GenerateIdentity that
 * generates an identity matrix of size 10
 * (i.e. a 10*10 square matrix with ones 
 * on the main diagonal and zeros elsewhere.) 
 */
namespace q6
{
    class Q6
    {
       // put your code here 

    }
}
