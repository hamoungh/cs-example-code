﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace q6
{
    class tester6
    {
        int[,] m=new Q6().GenerateIdentity(); 
    }
}
